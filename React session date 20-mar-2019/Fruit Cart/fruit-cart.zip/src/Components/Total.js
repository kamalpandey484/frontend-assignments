import React from 'react'

function Total(props) {
  return (
    <div className="App">
        <h1>Total:<span>{props.total}</span></h1>
    </div>
  );
}

export default Total