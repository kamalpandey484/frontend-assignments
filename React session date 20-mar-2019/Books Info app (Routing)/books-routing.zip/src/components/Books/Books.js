import React, { Component } from 'react';
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import {Card, Button} from 'react-bootstrap'

class Books extends Component
{
    render() {
        const book = this.props.book;
        return (
            <Link to={{pathname:`/bookdetail/${book.name}` , state:book}}>
                <Card style={{ width: '18rem'}} className="mt-2">
                    <Card.Img variant="top" src={book.url} style={{ height: '18rem'}}/>
                    <Card.Body>
                        <Card.Title>{book.name}</Card.Title>
                        <Button variant="primary">Check Details</Button>
                    </Card.Body>
                </Card>
            </Link>
        );
    }
}
export default Books;