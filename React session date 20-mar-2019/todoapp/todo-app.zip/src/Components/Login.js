import React, { Component } from "react";
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom";
import "../App";
import "bootstrap/dist/css/bootstrap.min.css";

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: "",
      password: ""
    };
  }
  handleChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  };

  render() {
    const { handleSubmit, isAuth, message } = this.props;
     if (isAuth) {
       return <Redirect to="/todo" />;
     }
    return (
      <div className="col-lg-6 mx-auto mt-5">
        <h2 className="text-center">Login Form</h2>
        <form onSubmit={event => handleSubmit(event, this.state)}>
          <div className="form-group">
            <input
              type={"text"}
              className={"form-control"}
              id={"exampleInputEmail1"}
              aria-describedby={"emailHelp"}
              placeholder={"Enter email"}
              onChange={this.handleChange}
              name={"user"}
              required
            />
          </div>
          <div className="form-group">
            <input
              type={"password"}
              className={"form-control"}
              id={"exampleInputPassword1"}
              placeholder={"Password"}
              name={"password"}
              onChange={this.handleChange}
              required
            />
          </div>
          <button type={"submit"} className="btn btn-primary" value={"Login"}>
            Submit
          </button>
        </form>
        <h3 className="text-primary mt-3">{message}</h3>
      </div>
    );
  }
}
