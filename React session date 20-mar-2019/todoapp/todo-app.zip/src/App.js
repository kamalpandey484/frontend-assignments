import React, { Component } from "react";
import ReactDOM from "react-dom";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect
} from "react-router-dom";
import Login from "./Components/Login";
import Main from "./Components/Main";
import "./App.css";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: "admin",
      password: "admin",
      isAuth: false,
      message: "Enter valid username and password"
    };
  }
  handleSubmit = (event, item) => {
    event.preventDefault();
    const { user, password } = this.state;
    if (item.user === user && item.password === password) {
      this.setState({
        isAuth: true
      });
    } else {
      this.setState({
        isAuth: false,
        message: "Please check username and password"
      });
    }
  };
  render() {
    return (
      <div className="App">
        <Router>
          <Switch>
            <Route
              path="/"
              exact
              render={props => (
                <Login
                  {...props}
                  handleSubmit={this.handleSubmit}
                  isAuth={this.state.isAuth}
                  message={this.state.message}
                />
              )}
            />
            <PrivateRoute path={"/todo"} component={Main} isAuth={this.state.isAuth}/>
          </Switch>
        </Router>
      </div>
    );
  }
}

export default App;

const PrivateRoute = ({ component: Component, ...rest }) => {
  console.log(rest);
  const {isAuth} = rest;
  return (
  <Route
  {...rest}
    render={(props) => isAuth ? <Component {...props} /> : <Redirect to={{pathName: "/"}} />}
  />
)};


const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
