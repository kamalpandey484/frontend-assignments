import React, { Component } from "react";
import Books from "../Books/Books.js";
import Book from "../BookData";

class BooksList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      books: Book
    };
  }
  render() {
    const items = this.state.books;
    return (
      <div className="d-flex justify-content-between flex-wrap">
        {items.map((item, i) => (
          <Books book={item} index={i} />
        ))}
      </div>
    );
  }
}
export default BooksList;
