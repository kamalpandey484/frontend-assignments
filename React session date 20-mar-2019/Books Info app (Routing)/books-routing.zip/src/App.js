import React, { Component } from "react";
import Login from "./components/Login/Login";
import Logout from "./components/Logout/Logout";
import "./App.css";
import {
  BrowserRouter as Router,
  Route,
  Redirect,
  Link
} from "react-router-dom";

import Header from "./components/Header";
import Home from "./components/Home";
import BooksList from "./components/BookList/BooksList";
import BookDetail from "./components/BookDetail/BookDetail";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: "admin",
      password: "admin",
      isAuth: false,
      message: "Enter valid username and password"
    };
  }

  isLogout = () => {
    this.setState({
      isAuth: false
    });
  };

  handleSubmit = (event, item) => {
    event.preventDefault();
    const { user, password } = this.state;
    if (item.user === user && item.password === password) {
      this.setState({
        isAuth: true
      });
    } else {
      this.setState({
        isAuth: false,
        message: "Please check username and password"
      });
    }
  };

  render() {
    const { user, password, isAuth } = this.state;
    return (
      <div className="App">
        <Router>
          <Header isAuth={isAuth} />
          <Route exact path="/" component={Home} />
          <Route
            path="/login"
            render={() => (
              <Login
                handleSubmit={this.handleSubmit}
                isAuth={isAuth}
                message={this.state.message}
              />
            )}
          />
          <Route
            path="/logout"
            render={() => (
              <Logout isAuth={isAuth} isLogout={this.isLogout} />
            )}
          />
          <PrivateRoute path="/Books" isAuth={isAuth} component={BooksList} />
          <PrivateRoute
            path="/bookdetail"
            isAuth={isAuth}
            component={BookDetail}
          />
        </Router>
      </div>
    );
  }
}

export default App;

const PrivateRoute = ({ component: Component, ...rest }) => {
  const { isAuth } = rest;
  return (
    <Route
      {...rest}
      render={props =>
        isAuth ? <Component {...props} /> : <Redirect to={{ pathName: "/" }} />
      }
    />
  );
};
