import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';

class Logout extends Component
{   
    render() {
        return (
             <section>
                 {this.props.isLogout()}
                 <h2>this is logout component</h2>
                 <Redirect to="/login"/>
             </section>
        );
    }
    
}   
export default Logout