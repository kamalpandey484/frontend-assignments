import {applyMiddleware, createStore} from 'redux';

const initialstate = { arr : []};

const reducer = (state = initialstate, action) => {
switch (action.type) {
  case 'ADD': {
    console.log("##########",action);
    const total = action.numbers.reduce((accumulator,currentValue) => accumulator + currentValue);
    console.log("Total is " + total);
    const numbers = action.numbers;
    return { numbers}
  }
  case 'DEL': {
    const numbers = state.numbers.filter(n=> n!== action.number );
    console.log("after deletion " + numbers);
    return {numbers};
  }
  case 'MUL': {
    console.log(state);
    const multotal = state.numbers.reduce((accumulator,currentValue) => accumulator=accumulator * currentValue,1);
    console.log("Multiplcation of entire array is " + multotal);
    return state;
  }
  default: {
   return state;
  }
}
}

const handleMultipleActions = store => next => action => {
  if(Array.isArray(action)) {
    console.log(action[0]);
    action.map(a => store.dispatch(a));
  } else {
    next(action);
  }
}

const middlewares = applyMiddleware(handleMultipleActions);
const store = createStore(reducer, middlewares);
store.subscribe(() => {
console.log("Store has changed", store.getState());
});

const addnumber = (numbers) => ({type : 'ADD', numbers}); 
const deletenumber = (number) => ({type : 'DEL', number}); 
const multiplynumber = () => ({type : 'MUL'}); 

store.dispatch([addnumber([1,2,3,4,5]), deletenumber(3), multiplynumber()]);