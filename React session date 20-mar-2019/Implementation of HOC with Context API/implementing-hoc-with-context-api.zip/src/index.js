import React, { Component } from "react";
import ReactDOM from "react-dom";
import userContext from "./context";
import Child1 from "./child/child1"

import "./styles.css";

class App extends Component {
  state = {
    user: { name: "kamal", pass: "*****" }
  };
  render(){
  return (
      <userContext.Provider value={this.state}>
        <div className="parent">
          <h1>Parent</h1>
          <p>
            Parent is setting its state in the context and is providing to the
            children.
          </p>
          <Child1 />
        </div>
      </userContext.Provider>
  );
}
}
export default App

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
