import React, { Component } from "react";

class BookDetail extends Component {
  render() {
    const { name, url, author, description } = this.props.location.state;
    return (
      <div className={"col-lg-8 mx-auto mt-5"}>
        <h1 className={"text-success"}> {name}</h1>
        <img src={url} />
        <h3 className={"text-info"}>{description}</h3>
        <h2 className={"text-warning"}> By : {author}</h2>
      </div>
    );
  }
}
export default BookDetail;
