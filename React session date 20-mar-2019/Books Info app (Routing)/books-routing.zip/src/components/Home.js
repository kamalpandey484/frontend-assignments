import React, { Component } from "react";

class Home extends Component {
  render() {
    return <p> Home Page </p>;
  }
}
export default Home;
