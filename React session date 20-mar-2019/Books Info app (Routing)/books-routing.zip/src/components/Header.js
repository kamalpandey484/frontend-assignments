import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Router } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { Navbar, Nav } from "react-bootstrap";

class Header extends Component {
  render() {
    let isAuth = this.props.isAuth;
    return (
      <Navbar bg="light" variant="light" className="justify-content-between">
        <Navbar.Brand>
          <Link to="/Books">BookApp</Link>
        </Navbar.Brand>
        <Nav>
          <Link to="/Books" className={"mr-4"}>
            Books
          </Link>
          {isAuth ? (
            <Link to="/logout" className="loginlink">
              Logout
            </Link>
          ) : (
            <Link to="/login" className="loginlink">
              Login
            </Link>
          )}
        </Nav>
      </Navbar>
    );
  }
}
export default Header;
